<div class="flex items-center justify-between w-full">
    <h1 class="text-xl font-semibold text-gray-800">@yield('page-title', 'Dashboard')</h1>
</div>

