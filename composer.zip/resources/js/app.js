import './bootstrap';

// AlpineJS for lightweight interactivity (searchable combobox, drawers, etc.)
import Alpine from 'alpinejs';
window.Alpine = Alpine;
Alpine.start();
